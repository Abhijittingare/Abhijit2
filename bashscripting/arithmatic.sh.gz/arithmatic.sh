#!/bin/bash
#echo $((11.22+22.32))
echo 11.22+22.32 | bc
